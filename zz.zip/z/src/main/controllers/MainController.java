package main.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {
	@GetMapping("/")
	public String getIndex() {
		return "HomeProcurement";
	}

	@GetMapping("/grnData")
	public String getGrn() {
		return "grnlist";
	}

	@GetMapping("/createGRN")
	public String createGRN() {
		return "create-grn";
	}

	@GetMapping("/purchaseOrderData")
	public String purchaseOrderData() {
		return "purchase order data";
	}

	@GetMapping("/createPurchaseOrder")
	public String createPurchaseOrder() {
		return "purchase orders";
	}

	@GetMapping("/createNewPurchaseOrders")
	public String createNewPurchaseOrders() {
		return "purchase orders from scratch";
	}

	@GetMapping("/indents")
	public String indents() {
		return "indents";
	}

	@GetMapping("/prnData")
	public String prnData() {
		return "prnlist";
	}

	@GetMapping("/createPRN")
	public String createPRN() {
		return "createprn";
	}
	
	@GetMapping("/addHSN")
	public String addHSN() {
		return "addHSN";
	}
	
	@GetMapping("/addProductCategory")
	public String addProductCategory() {
		return "addProductCategory";
	}
	@GetMapping("/addProduct")
	public String addProduct() {
		return "addProduct";
	}
}
