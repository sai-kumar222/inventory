package com.sai.spring.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.sai.spring.DAO.StudentDao;

@Controller
public class MainController {

	@Autowired
	public StudentDao studentDao;

	@GetMapping("/showstudents")
	public String show(Model model) {
		model.addAttribute("students", studentDao.getAllStudents());
		return "student";
	}

}
