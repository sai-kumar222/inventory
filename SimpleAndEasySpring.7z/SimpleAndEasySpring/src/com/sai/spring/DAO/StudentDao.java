package com.sai.spring.DAO;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Component;

import com.sai.spring.Models.StudentModel;

@Component
public class StudentDao {

	@PersistenceContext
	public EntityManager entityManager;

	@Transactional
	public List<StudentModel> getAllStudents() {
		List<StudentModel> l = entityManager.createQuery("select s from StudentModel s").getResultList();
		for (StudentModel i : l) {
			System.out.println(i);
		}
		return l;
	}
}
